Summer Travel Survey 2018
October 1st, 2018
Fore more information contact Reid Haefer (rhaefer@trpa.org)

There are two files associated with this dataset 1) a .csv file that contains all of the survey data & 2) a data dictionary which defines the fields in the dataset. 

Each row in the survey dataset contains a unique id found in the'survey_id' field. Each row also contains all the survey response attribute data for that unique survey id. If you are not interested in analyzing the different types of GPS points and are simply interested in the survey response data, you can filter 'gps_point_category'='survey location' and this will only give you the survey locations and the survey attribute data. Additionally, if you are not interested in the response rate of the survey, the first thing you should do is filter 'survey_rejected' = 'no'. Filtering for 'no' will give you all surveys that were not rejected (ie ones that were completed).  If you filter 'gps_point_category'='survey location' and 'survey_rejected'='no', this will give you the completed 1,048 survey records, including the survey locations.

If you are interested in analyzing the spatial aspects of the survey you can look at the different types of GPS points. Each row in the dataset contains a GPS (lat,lon) point. There are 4 different types of GPS points, which are labeled in the 'gps_point_category' field: 1) Survey Location 2) Permanent Home Location 3) Overnight Lodging Location 4) Seasonal Home Location. 